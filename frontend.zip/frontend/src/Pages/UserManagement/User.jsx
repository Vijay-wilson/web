import React, { useState, useEffect } from "react";
import axios from "axios";
import NavBar from "../NavBar/NavBar"

import { BASE_URL } from "../../../service";
const User = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/users`);
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
  
    fetchData();
  }, []);
  
  return (
 
        <div >
            <NavBar/>
          {/* <h1
            style={{
              margin: "24px",
              display: "flex",
              justifyContent: "center",
            }}
          >
            User Management
          </h1> */}
          <table style={{ borderCollapse: "collapse", width: "95%",marginLeft:"32px" }}>
            <thead>
              <tr>
                <th style={tableHeaderStyle}>ID</th>
                <th style={tableHeaderStyle}>Full Name</th>
                <th style={tableHeaderStyle}>Email</th>
                <th style={tableHeaderStyle}>Phone Number</th>
                <th style={tableHeaderStyle}>Created At</th>
                <th style={tableHeaderStyle}>House Name</th>
                <th style={tableHeaderStyle}>Road & Location</th>
                {/* <th style={tableHeaderStyle}>Area</th> */}
                <th style={tableHeaderStyle}>Locality</th>
                <th style={tableHeaderStyle}>Route</th>
                {/* <th style={tableHeaderStyle}>User Info</th> */}
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td style={tableCellStyle}>{user.id}</td>
                  <td style={tableCellStyle}>{user.first_name}</td>
                  <td style={tableCellStyle}>{user.last_name}</td>
                  <td style={tableCellStyle}>{user.phone_number}</td>
                  <td style={tableCellStyle}>{user.created_at}</td>
                  <td style={tableCellStyle}>{user.house_name}</td>
                  <td style={tableCellStyle}>{user.road_and_location}</td>
                  {/* <td style={tableCellStyle}>{user.area}</td> */}
                  <td style={tableCellStyle}>{user.locality}</td>
                  <td style={tableCellStyle}>{user.route}</td>
                  {/* <td style={tableCellStyle}>{user.userinfo}</td> */}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

  );
};

const tableHeaderStyle = {
  border: "1px solid #dddddd",
  padding: "8px",
  backgroundColor: "#f2f2f2",
  fontWeight: "bold",
};

const tableCellStyle = {
  border: "1px solid #dddddd",
  padding: "8px",
};

export default User;
