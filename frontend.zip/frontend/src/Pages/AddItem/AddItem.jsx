import React, { useEffect, useState } from "react";
import { Table, Modal, Form, Button } from "react-bootstrap";
// import PrimaryButton from "../../UTIL/Buttons/PrimaryButton";
// import InactiveButton from "../../UTIL/Buttons/InactiveButton";
// import Add from "../../../SVG/Add";
// import Delete from "../../../SVG/Delete";
// import SearchContainer from "../../UTIL/SearchContainer";
import "./AddItem.css";
// import useTable from "../../Create/useTable";
// import TableFooter from "../../Create/TableFooter";
import ImageModal from "../AddItem/ImageModal";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { BASE_URL } from "../../../service";
import NavBar from "../NavBar/NavBar";
function AddItem() {
  const [modalShow, setModalShow] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    image_url: "",
    vegType: "",
    type: "",
    ingredient: "",
    price: "",
    status: "",
  });
  //   const addonsList = useSelector((state) => state.addons.addonsList);
  const [search, setSearch] = useState("");
  // const [page, setPage] = useState(1);
  const [addonsList, setAddonsList] = useState([]);
  // const { slice, range } = useTable(addonsList, page, 3);
  // const [quantities, setQuantities] = useState({});

  const [selectedItems, setSelectedItems] = useState([]);
  const [smallImageModalShow, setSmallImageModalShow] = useState(false);
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch(`${BASE_URL}/getfoodItems`);
      const data = await response.json();
      if (response.ok) {
        setAddonsList(data);
      } else {
        console.error("Error fetching data:", data.message);
      }
    } catch (error) {
      console.error("Error fetching data:", error.message);
    }
  };

  const handleChange = (e) => {
    setSearch(e.target.value);
  };

  const handleFormChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleModalSubmit = async () => {
    try {
      const formattedData = {
        item_name: formData.name,
        item_image: formData.image_url,
        item_url: formData.type,
        item_type: formData.vegType,
        item_description: formData.ingredient,
        item_price: parseFloat(formData.price),
        status: true,
        item_qty: 0
      };

      const response = await fetch(`${BASE_URL}/addFoodItem`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formattedData),
      });
      const data = await response.json();
      if (response.ok) {
        toast.success(data.message);
        setModalShow(false);
        // onnu koode vilicahl mathi auto reload ayikollum
        fetchData();
      } else {
        toast.error("Error: " + data.message);
      }
    } catch (error) {
      toast.error("Error: " + error.message);
    }
  };

  const handleOpenModal = () => {
    setFormData({
      name: "",
      image_url: "",
      vegType: "",
      type: "",
      ingredient: "",
      price: "",
      status: "",
    });
    setModalShow(true);
  };

  const [imageModalShow, setImageModalShow] = useState(false);

  const handleImageSelect = (imageUrl) => {
    // Use the selected image URL
    setFormData({ ...formData, image_url: imageUrl });
    console.log("tt", imageUrl);
    setImageModalShow(false);
  };

  const handleStatusToggle = async (index) => {
    try {
      const updatedAddonsList = [...addonsList];
      updatedAddonsList[index].status = !updatedAddonsList[index].status;

      const response = await fetch(
        `${BASE_URL}/addons/${updatedAddonsList[index].id}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ status: updatedAddonsList[index].status }),
        }
      );

      const data = await response.json();
      console.log(data);
      if (response.ok) {
        toast.success(data.message);
        setAddonsList(updatedAddonsList);
      } else {
        toast.error("Error: " + data.message);
      }
    } catch (error) {
      toast.error("Error: " + error.message);
    }
  };
  // increment quantity
  const handleIncrement = async (id) => {
    try {
      // Make API call to increment quantity
      const response = await fetch(`${BASE_URL}/increment/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ Id: id }),
      });
      const data = await response.json();
      if (response.ok) {
        // Update quantities state
        // setQuantities((prevQuantities) => ({
        //   ...prevQuantities,
        //   [id]: prevQuantities[id] + 1,
        // }));
      } else {
        console.error("Error incrementing quantity:", data.message);
      }
    } catch (error) {
      console.error("Error incrementing quantity:", error.message);
    }
    fetchData();
  };

  //  quantity decrement
  const handleDecrement = async (id) => {
    try {
      // Make API call to decrement quantity
      const response = await fetch(`${BASE_URL}/decrement/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ Id: id }),
      });
      const data = await response.json();
      if (response.ok) {
        // Update quantities state
        // setQuantities((prevQuantities) => ({
        //   ...prevQuantities,
        //   [id]: Math.max(0, prevQuantities[id] - 1),
        // }));
      } else {
        console.error("Error decrementing quantity:", data.message);
      }
    } catch (error) {
      console.error("Error decrementing quantity:", error.message);
    }
    fetchData();
  };

  // deletion
  const handleDeleteSelected = async () => {
    try {
      // Make API call to delete selected items
      const response = await Promise.all(
        selectedItems.map(async (id) => {
          const deleteResponse = await fetch(
            `${BASE_URL}/deleteFoodItem/${id}`,
            {
              method: "DELETE",
            }
          );
          return deleteResponse.json();
        })
      );

      // Handle response
      response.forEach((res) => {
        if (res.message) {
          toast.success(res.message);
        } else {
          toast.error("Failed to delete some items");
        }
      });

      // Refresh data
      fetchData();
      // Clear selected items
      setSelectedItems([]);
    } catch (error) {
      console.error("Error deleting items:", error.message);
      toast.error("Error deleting items");
    }
  };
  const toggleSelection = (id) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter((item) => item !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleSmallImageSelect = (imageUrl) => {
    setFormData({ ...formData, type: imageUrl });
    setSmallImageModalShow(false);
  };

  return (
    <div style={{ flex: 1 }}>
      <NavBar />
      <ToastContainer />
      {/* Modal */}
      <Modal show={modalShow} onHide={() => setModalShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Food Item</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <div className="row">
              <div className="col-md-6">
                <Form.Group controlId="vegType">
                  <Form.Label>Item Nmae</Form.Label>
                  <Form.Control
                    as="select"
                    name="vegType"
                    value={formData.vegType}
                    onChange={handleFormChange}
                  >
                    <option value="Select">Select Name</option>
                    <option value="Burger">Burger</option>
                    <option value="Milk-Shake">Milk Shake</option>
                    <option value="Cake">Cake</option>
                    <option value="Soft drinks">Soft drinks</option>
                    <option value="Wrap">Wrap</option>
                    <option value="Premium burgers">Premium burgers</option>
                    <option value="Juice">Juice</option>
                    <option value="Fresh Burger">Fresh Burger</option>
                    <option value="Pasta">Pasta</option>
                    <option value="Poratta">Poratta</option>
                  </Form.Control>
                </Form.Group>
              </div>
              <div className="col-md-6">
                <Form.Group controlId="type">
                  <Form.Label>Avatar</Form.Label>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <div style={{ paddingBottom: "10px" }}>
                      <img
                        src={formData.type}
                        style={{
                          height: "60%",
                          width: "60%",
                          borderRadius: "8px",
                          marginRight: "10px",
                        }}
                        alt="Preview"
                      />
                    </div>
                  </div>
                </Form.Group>
                <Button
                  variant="outline-success"
                  onClick={() => setSmallImageModalShow(true)}
                >
                  Upload avatar
                </Button>
              </div>
            </div>

            <Form.Group controlId="name">
              <Form.Label>Item Name</Form.Label>
              <Form.Control
                as="select"
                name="name"
                value={formData.name}
                onChange={handleFormChange}
              >
                <option value="Select">Select Name</option>
                {formData.vegType === "Burger" && (
                  <>
                    <option value="Chi-BeefBurger">Chi-BeefBurger</option>
                    <option value="Chi-LemonBurger">Chi-LemonBurger</option>
                    <option value="Chi-TandooriBurger">
                      Chi-TandooriBurger
                    </option>
                    <option value="CrispyBurger">CrispyBurger</option>
                    <option value="DoubleBurger">DoubleBurger</option>
                    <option value="DragonBurger">DragonBurger</option>
                    <option value="FishBurger">FishBurger</option>
                    <option value="JumboPrawnsBurger">JumboPrawnsBurger</option>
                    <option value="KentakyBurger">KentakyBurger</option>
                    <option value="KhaleejBurger">KhaleejBurger</option>
                    <option value="KhaleejDoubleBurger">
                      KhaleejDoubleBurger
                    </option>
                    <option value="MegaZinker">MegaZinker</option>
                  </>
                )}
                {formData.vegType === "Milk-Shake" && (
                  <>
                    <option value="Lotus-Milk-shake">Lotus-Milk-shake</option>
                    <option value="Nutella-Milk-shake">
                      Nutella-Milk-shake
                    </option>
                    <option value="Oreo-Milk-Shake">Oreo-Milk-Shake</option>
                    <option value="Raffaello-shake">Raffaello-shake</option>
                    <option value="kinderJoy-Milk-shake">
                      kinderJoy-Milk-shake
                    </option>
                  </>
                )}
                {formData.vegType === "Cake" && (
                  <>
                    <option value="CakeZafran">CakeZafran</option>
                    <option value="HoneyCake">HoneyCake</option>
                    <option value="Londoncake">Londoncake</option>
                  </>
                )}
                {formData.vegType === "Soft drinks" && (
                  <>
                    <option value="CarbonatedSoftDrinks">
                      CarbonatedSoftDrinks
                    </option>
                  </>
                )}
                {formData.vegType === "Wrap" && (
                  <>
                    <option value="AlaKaifak">AlaKaifak</option>
                    <option value="AnimalStyleFries">AnimalStyleFries</option>
                    <option value="ButterflyWrap">ButterflyWrap</option>
                    <option value="ClassicWrap">ClassicWrap</option>
                    <option value="MathafiWrap">MathafiWrap</option>
                    <option value="ShishTawook">ShishTawook</option>
                    <option value="TandooriArabic">TandooriArabic</option>
                    <option value="TwisterWrap">TwisterWrap</option>
                    <option value="ZingerWrap">ZingerWrap</option>
                    <option value="ZinkerArabic">ZinkerArabic</option>
                  </>
                )}
                {formData.vegType === "Premium burgers" && (
                  <>
                    <option value="GrilledBurger-Chi-Beef">
                      GrilledBurger-Chi-Beef
                    </option>
                    <option value="GrilledChiLemonBurger">
                      GrilledChiLemonBurger
                    </option>
                    <option value="ItalianCombo">ItalianCombo</option>
                    <option value="PremierZinker">PremierZinker</option>
                    <option value="SpanishCombo">SpanishCombo</option>
                    <option value="TurkishBurger">TurkishBurger</option>
                    <option value="ZinkerTurkishBurger">
                      ZinkerTurkishBurger
                    </option>
                    <option value="BeefBaconDoubIeBurger">
                      BeefBaconDoubIeBurger
                    </option>
                    <option value="BurgerSpotSpecial">BurgerSpotSpecial</option>
                    <option value="CalzoniCombo">CalzoniCombo</option>
                    <option value="ChickenPane">ChickenPane</option>
                  </>
                )}
                {formData.vegType === "Juice" && (
                  <>
                    <option value="LiverCure">LiverCure</option>
                    <option value="Mango">Mango</option>
                    <option value="MangoBanana">MangoBanana</option>
                    <option value="MangoMint">MangoMint</option>
                    <option value="MangoPeach">MangoPeach</option>
                    <option value="MangoRaspberry">MangoRaspberry</option>
                    <option value="MaryMad">MaryMad</option>
                    <option value="Peach">Peach</option>
                    <option value="PinkBeauty">PinkBeauty</option>
                    <option value="PinkExotic">PinkExotic</option>
                    <option value="PinkLemon">PinkLemon</option>
                    <option value="Pistacho">Pistacho</option>
                    <option value="QueenofHeart">QueenofHeart</option>
                    <option value="Raspberry-Smoothy">Raspberry-Smoothy</option>
                    <option value="Respberry">Respberry</option>
                    <option value="RubRuman">RubRuman</option>
                    <option value="StrawBerry">StrawBerry</option>
                    <option value="StrawberrySmoothie">
                      StrawberrySmoothie
                    </option>
                    <option value="Tabakath">Tabakath</option>
                    <option value="Tasty">Tasty</option>
                    <option value="Thalavani">Thalavani</option>
                    <option value="Vampire">Vampire</option>
                    <option value="VitaminLoad">VitaminLoad</option>
                    <option value="WeightLoss">WeightLoss</option>
                  </>
                )}
                {formData.vegType === "Fresh Burger" && (
                  <>
                    <option value="Beef-bacon">Beef-bacon</option>
                    <option value="Beef-BaconBurger">Beef-BaconBurger</option>
                    <option value="CheetosBurger">CheetosBurger</option>
                    <option value="Crispy-Cheetos">Crispy-Cheetos</option>
                    <option value="Crispyoman">Crispyoman</option>
                    <option value="DoubleBeef-Chicken">
                      DoubleBeef-Chicken
                    </option>
                    <option value="Dynamite-chickenBurger">
                      Dynamite-chickenBurger
                    </option>
                    <option value="Dynamite-Prawns">Dynamite-Prawns</option>
                    <option value="Fatboy-Burger">Fatboy-Burger</option>
                    <option value="Grilled-BeeefBurger">
                      Grilled-BeeefBurger
                    </option>
                    <option value="Grilled-ChickenBurger">
                      Grilled-ChickenBurger
                    </option>
                    <option value="Manhatten-SpicyBurger">
                      Manhatten-SpicyBurger
                    </option>
                    <option value="Mushroom-Burger">Mushroom-Burger</option>
                    <option value="Pineapple_Burger">Pineapple_Burger</option>
                    <option value="Royal-Burger">Royal-Burger</option>
                    <option value="RumanBurger">RumanBurger</option>
                    <option value="Signature_Burger">Signature_Burger</option>
                    <option value="Stufed_CheeseBurger">
                      Stufed_CheeseBurger
                    </option>
                    <option value="TakisBurger">TakisBurger</option>
                    <option value="Tasty-crispy">Tasty-crispy</option>
                    <option value="ZingerClassic">ZingerClassic</option>
                  </>
                )}
                {formData.vegType === "Pasta" && (
                  <>
                    <option value="CheetosPasta">CheetosPasta</option>
                    <option value="PastaChicken">PastaChicken</option>
                    <option value="PastaOman">PastaOman</option>
                  </>
                )}
                {formData.vegType === "Poratta" && (
                  <>
                    <option value="BeefNashifPorotta">BeefNashifPorotta</option>
                    <option value="CheetosChilliPorotta">
                      CheetosChilliPorotta
                    </option>
                    <option value="CheetosPorotta">CheetosPorotta</option>
                    <option value="ChiChilliPorotta">ChiChilliPorotta</option>
                    <option value="EggPorotta">EggPorotta</option>
                    <option value="FranciscoPorotta">FranciscoPorotta</option>
                    <option value="HotdogPorotta">HotdogPorotta</option>
                    <option value="KeemaPorotta">KeemaPorotta</option>
                    <option value="MathafiPorottaCombo">
                      MathafiPorottaCombo
                    </option>
                    <option value="OmanChipsPorotta">OmanChipsPorotta</option>
                    <option value="OmlettePorotta">OmlettePorotta</option>
                    <option value="porotta">porotta</option>
                    <option value="ShishTawookPorotta">
                      ShishTawookPorotta
                    </option>
                    <option value="TarteebPorotta">TarteebPorotta</option>
                  </>
                )}
              </Form.Control>
            </Form.Group>

            <Form.Group controlId="ingredient">
              <Form.Label>Description</Form.Label>
              <Form.Control
                type="text"
                name="ingredient"
                value={formData.ingredient}
                onChange={handleFormChange}
              />
            </Form.Group>
            <Form.Group controlId="price">
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="text"
                name="price"
                value={formData.price}
                onChange={handleFormChange}
              />
            </Form.Group>
            <Form.Group controlId="image_url">
              <Form.Label>Image</Form.Label>
              <div style={{ display: "flex", alignItems: "center" }}>
                <div style={{ padding: "10px" }}>
                  <img
                    src={formData.image_url}
                    style={{
                      height: "70%",
                      width: "70%",
                      borderRadius: "8px",
                      marginRight: "10px",
                    }}
                    alt="Preview"
                  />
                </div>
              </div>
            </Form.Group>

            <Button
              variant="outline-success"
              onClick={() => setImageModalShow(true)}
            >
              Upload image
            </Button>
            {/* 
            <Form.Group controlId="type">
              <Form.Label>Small Image</Form.Label>
              <div style={{ display: "flex", alignItems: "center" }}>
                <div style={{ padding: "10px" }}>
                  <img
                    src={formData.type}
                    style={{
                      height: "70%",
                      width: "70%",
                      borderRadius: "8px",
                      marginRight: "10px",
                    }}
                    alt="Preview"
                  />
                </div>
              </div>
            </Form.Group>

            <Button
              variant="primary"
              onClick={() => setSmallImageModalShow(true)}
            >
              Upload small image
            </Button> */}

            <ImageModal
              show={smallImageModalShow}
              onHide={() => setSmallImageModalShow(false)}
              onSelectImage={handleSmallImageSelect}
            />

            <ImageModal
              show={imageModalShow}
              onHide={() => setImageModalShow(false)}
              onSelectImage={handleImageSelect}
            />
          </Form>
        </Modal.Body>
        <div style={{ margin: 16 }}>
          <Button variant="outline-success" onClick={handleModalSubmit}>
            Submit
          </Button>
        </div>
      </Modal>
      {/* Buttons and Search */}
      <div style={{ display: "flex", height: "2.5rem", marginBottom: "1rem" }}>
        <div
          style={{ display: "flex", flex: 1, justifyContent: "space-between" }}
        >
          <Button onClick={handleOpenModal} variant="outline-success">
            Add New
          </Button>
          <Button onClick={handleDeleteSelected} variant="outline-danger">
            Delete
          </Button>
        </div>
        {/* <div style={{ flex: 1, marginLeft: "3rem" }}>
          <SearchContainer search={search} handleChange={handleChange} />
        </div> */}
      </div>

      {/* Table */}
      <Table style={{ border: "1px solid #E9E9E9", color: "#1F3A68" }}>
        <thead style={{ backgroundColor: "#FFFAE5" }}>
          <tr>
            <th>
              <input type="checkbox" />
            </th>
            <th>Item Image</th>
            <th>Price</th>
            <th>Name</th>
            <th>Avatar</th>
            <th>Item Type</th>
            {/* <th>Description</th> */}
            <th>Quantity</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody style={{ backgroundColor: "white" }}>
          {addonsList.map((item, index) => (
            <tr key={index}>
              <td valign="middle">
                <input
                  type="checkbox"
                  checked={selectedItems.includes(item.id)}
                  onChange={() => toggleSelection(item.id)}
                />
              </td>
              <td valign="middle">
                <img
                  src={item.item_image}
                  style={{
                    height: "64px",
                    width: "64px",
                    borderRadius: "8px",
                  }}
                  alt="Food"
                />
              </td>
              <td valign="middle">₹{item.item_price}</td>
              <td valign="middle">{item.item_name}</td>
              <td valign="middle">
                <img
                  src={item.item_url}
                  style={{
                    height: "64px",
                    width: "64px",
                    borderRadius: "8px",
                  }}
                  alt="Food"
                />
              </td>
              {/* <td valign="middle">{item.item_description}</td> */}
              <td valign="middle">{item.item_type}</td>
              <td valign="middle">
                <Button
                  variant="outline-secondary"
                  onClick={() => handleDecrement(item.id)}
                >
                  -
                </Button>
                <span style={{ margin: "0 5px" }}> {item.item_qty}</span>
                <Button
                  variant="outline-secondary"
                  onClick={() => handleIncrement(item.id)}
                >
                  +
                </Button>
              </td>
              <td valign="middle">
                <button
                  onClick={() => handleStatusToggle(index)}
                  style={{
                    backgroundColor: item.status ? "green" : "red",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    padding: "8px 12px",
                    cursor: "pointer",
                  }}
                >
                  {item.status ? "Enable" : "Disable"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* <TableFooter range={range} slice={slice} setPage={setPage} page={page} /> */}
    </div>
  );
}

export default AddItem;
