import React, { useEffect, useState } from "react";
import { Modal, Image, Card, Button } from "react-bootstrap";
import { BASE_URL } from "../../../service";


function ImageModal({ show, onHide, onSelectImage }) {
  const [images, setImages] = useState([]);

  useEffect(() => {
    if (show) {
      fetchImages();
    }
  }, [show]);

  const fetchImages = async () => {
    try {
      const response = await fetch(`${BASE_URL}/listImages`);
      const data = await response.json();
      if (response.ok) {
        setImages(data);
      } else {
        console.error("Error fetching images:", data.message);
      }
    } catch (error) {
      console.error("Error fetching images:", error.message);
    }
  };

  const getImageName = (imageUrl) => {
    const urlParts = imageUrl.split("/");
    const fileName = urlParts[urlParts.length - 1];
    const nameWithoutExtension = fileName.split(".")[0];
    return nameWithoutExtension;
  };

  return (
    <Modal show={show} onHide={onHide} fullscreen={false} size="xl">
      <Modal.Header closeButton>
        <Modal.Title>Select Image</Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ display: "flex", flexWrap: "wrap" }}>
        {images.map((image) => (
          <div
            key={image.id}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              marginRight: "20px",
              // marginBottom: "20px",
            }}
          >
            <Card
              style={{ width: "100px", cursor: "pointer" }}
              onClick={() => {
                onSelectImage(image.image_url);
              }}
            >
              <Card.Img variant="top" src={image.image_url} />
            </Card>
            <p>{getImageName(image.image_url)}</p>
          </div>
        ))}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default ImageModal;