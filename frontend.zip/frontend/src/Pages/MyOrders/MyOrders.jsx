import React from 'react'
import Navbar from '../NavBar/NavBar'

const MyOrders = () => {
  return (
    <div>
        <Navbar />
      MyOrders
    </div>
  )
}

export default MyOrders
