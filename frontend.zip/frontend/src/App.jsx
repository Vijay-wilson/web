import React, { useState } from "react";
import Navbar from "./Components/Navbar/Navbar";
import { Route, Routes } from "react-router-dom";
import Home from "./Pages/Home/Home";
import Cart from "./Pages/Cart/Cart";
import PlaceOrder from "./Pages/PlaceOrder/PlaceOrder";
import Footer from "./Components/Footer/Footer";
import LoginPopup from "./Components/LoginPopup/LoginPopup";
import SavedImages from "./Pages/SavedImages/SavedImages";
import MyOrders from "./Pages/MyOrders/MyOrders";
import AddItem from "./Pages/AddItem/AddItem";
import User from "./pages/UserManagement/User";
const App = () => {
  const [showLogin, setShowLogin] = useState(false);

  return (
    <>
      {showLogin ? <LoginPopup setShowLogin={setShowLogin} /> : <> </>}
      <div className="app">
        <Navbar setShowLogin={setShowLogin} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/" element={<Cart />} />
          <Route path="/" element={<PlaceOrder />} />
          {/* ADMIN */}
          <Route path="/user" element={<User />} />
          <Route path="/images" element={<SavedImages />} />
          <Route path="/myorders" element={<MyOrders />} />
          <Route path="/additem" element={<AddItem />} />
        </Routes>
      </div>
      <Footer />
    </>
  );
};

export default App;
