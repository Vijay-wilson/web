import React, { useState, useEffect, useContext } from "react";
import "./ExploreMenu.css";
import FoodItem from "../FoodItem/FoodItem";
import { StoreContext } from "../../Context/StoreContext";

const ExploreMenu = () => {
  const [category, setCategory] = useState("All");
  const [foodItems, setFoodItems] = useState([]);
  const [menuList, setMenuList] = useState([]);
  const { cartItems, addToCart, removeFromCart } = useContext(StoreContext);

  useEffect(() => {
    fetchFoodItems();
  }, []);

  const fetchFoodItems = async () => {
    try {
      const response = await fetch("http://localhost:5001/getfoodItems");
      const data = await response.json();
      setFoodItems(data);
      
      // Create menu list dynamically from the fetched data
      const uniqueTypes = [...new Set(data.map(item => item.item_type))];
      const newMenuList = uniqueTypes.map(type => ({
        menu_name: type,
        menu_image: data.find(item => item.item_type === type)?.item_url || ''
      }));
      setMenuList(newMenuList);
    } catch (error) {
      console.error("Error fetching food items:", error);
    }
  };

  return (
    <div className="explore-menu" id="explore-menu">
      <h1 style={{marginTop:16}}>Explore our menu</h1>
      <p className="explore-menu-text">
        Choose from a diverse menu featuring a delectable array of dishes. Our
        mission is to satisfy your cravings and elevate your dining experience,
        one delicious meal at a time.
      </p>
      <div className="explore-menu-list">
        {menuList.map((item, index) => {
          return (
            <div
              onClick={() =>
                setCategory((prev) =>
                  prev === item.menu_name ? "All" : item.menu_name
                )
              }
              key={index}
              className="explore-menu-list-item"
            >
              <img
                className={category === item.menu_name ? "active" : ""}
                src={item.menu_image}
                alt={item.menu_name}
              />
              <p>{item.menu_name}</p>
            </div>
          );
        })}
      </div>
      <hr />
      <div className='food-display' id='food-display'>
        <h2>Top dishes near you</h2>
        <div className="food-display-list">
          {foodItems.map((item) => {
            if (category === "All" || category === item.item_type) {
              return (
                <FoodItem
                  key={item.id}
                  id={item.id}
                  name={item.item_name}
                  description={item.item_description}
                  price={item.item_price}
                  image={item.item_image}
                  cartItems={cartItems}
                  addToCart={addToCart}
                  removeFromCart={removeFromCart}
                />
              );
            }
            return null;
          })}
        </div>
      </div>
    </div>
  );
};

export default ExploreMenu;