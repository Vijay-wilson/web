import './LoginPopup.css';
import { useState } from 'react';
import { assets } from '../../assets/assets';

// eslint-disable-next-line react/prop-types
const LoginPopup = ({ setShowLogin }) => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });

  const handleLogin = (event) => {
    event.preventDefault();
    // Check if the entered credentials match the hardcoded ones
    if (credentials.email === 'uaeburgerspot@gmail.com' && credentials.password === '1234') {
      // Navigate to /home
      window.location.href = '/myorders';
    } else {
      // Handle invalid credentials
      alert('Invalid email or password');
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setCredentials({ ...credentials, [name]: value });
  };

  return (
    <div className='login-popup'>
      <form className="login-popup-container" onSubmit={handleLogin}>
        <div className="login-popup-title">
          <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="" />
        </div>
        <div className="login-popup-inputs">
          <input
            name='email'
            type="email"
            placeholder='Your email'
            value={credentials.email}
            onChange={handleInputChange}
            required
          />
          <input
            name='password'
            type="password"
            placeholder='Password'
            value={credentials.password}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type='submit'>Login</button>
        <div className="login-popup-condition">
          <input type="checkbox" required />
          <p className='continuee'>By continuing, I agree to the terms of use & privacy policy</p>
        </div>
      </form>
    </div>
  );
};

export default LoginPopup;
