import React from 'react'
import './Footer.css'
import { assets } from '../../assets/assets'

const Footer = () => {
  return (
    <div className='footer' id='footer'>
       <div className="footer-content">
        <div className="footer-content-left">
        <h1 style={{color:"red"}}>Burger Spot</h1>
            <p>At Burgerspot, we serve up mouthwatering burgers made from fresh, quality ingredients and deliver them right to your door. Whether you’re in the mood for a classic or something with a twist, we’ve got the perfect burger to hit the spot.Order from Burgerspot today and enjoy a great meal without leaving home!</p>
            <div className="footer-social-icons">
                <img src={assets.facebook_icon} alt="" />
                <img src={assets.twitter_icon} alt="" />
                <img src={assets.linkedin_icon} alt="" />
            </div>
            </div>
            <div className="footer-content-center">
                <h2>COMPANY</h2>
                <ul>
                    <li>Home</li>
                    <li>About us</li>
                    <li>Delivery</li>
                    <li>Privacy policy</li>
                </ul>
            </div>
        <div className="footer-content-right">
            <h2>GET IN TOUCH</h2>
            <ul>
                <li>Near Al Shaheed Al Quba Mosque, Al Falah City, Abu Dhabi</li>
                <li>+1-212-456-7890</li>
                <li>burgerspotuae@gmail.com</li>
            </ul>
        </div>
       </div> 
       <hr /> 
       <p className="footer-copyright">Copyright2024@Burger.com-All Right Reserved</p>
    </div>
  )
}

export default Footer