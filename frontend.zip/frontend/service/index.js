export const BASE_URL = "https://burgerspotcafeteria.com:5001";
// export const BASE_URL = "http://localhost:5001";