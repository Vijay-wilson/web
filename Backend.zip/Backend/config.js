module.exports = {
    apiKey: "9e681630f917327445198eac1ea4a14c57a2092839c7b54c08a8d599c0c52c89",
    jwtSecretKey: "your_secret_key", 
    database: {
      user: "postgres",
      host: "localhost",
      name: "lalas",
      password: "143143",
      port: 5432,
    },
  };
  