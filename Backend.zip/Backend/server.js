
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const https = require('https');
const fs = require('fs');
// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

//  your API key 
const apiKey = '12345';

// Middleware to check API key
const apiKeyMiddleware = (req, res, next) => {
  const providedApiKey = req.headers['x-api-key'];

  if (!providedApiKey || providedApiKey !== apiKey) {
    return res.status(401).json({ error: 'Unauthorized. Invalid API key.' });
  }
  next();
};

app.use(apiKeyMiddleware);

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'bayesian',
  password: '143143',
  port: 5432,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});


// Function to create the database if it doesn't exist
const createDatabase = async () => {
  const tempPool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres', 
    password: '143143',
    port: 5432,
  });

  try {
    // Create the database
    await tempPool.query('CREATE DATABASE bayesian');
    console.log('database created successfully');
  } catch (error) {
    if (error.code === '42P04') {
      // Database already exists
      console.log('database already exists');
    } else {
      console.error('Error creating database:', error);
      process.exit(-1);
    }
  } finally {
    // Close the temporary pool
    await tempPool.end();
  }
};

// Function to create the table

// Function to create the table
const createTable = async () => {
  try {
    const client = await pool.connect();
    const query = `
      CREATE TABLE IF NOT EXISTS contact (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        companyName VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        message TEXT NOT NULL
      )
    `;
    await client.query(query);
    console.log('Table created successfully');
    client.release();
  } catch (error) {
    console.error('Error creating table:', error);
    throw error;
  }
};

// Define a POST route for collecting data
app.post('/contact-data', async (req, res) => {
  try {
    const { name, email, companyName, phone, message } = req.body;

    const client = await pool.connect();
    const query = `
      INSERT INTO contact (name, email, companyName, phone, message)
      VALUES ($1, $2, $3, $4, $5)
    `;
    await client.query(query, [name, email, companyName, phone, message]);
    console.log('Data inserted successfully');
    client.release();

    res.status(201).json({ message: 'Data inserted successfully' });
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Define a GET route for retrieving data
app.get('/contact-data', async (req, res) => {
  try {
    const client = await pool.connect();
    const query = 'SELECT * FROM contact';
    const { rows } = await client.query(query);
    console.log('Data retrieved successfully');
    client.release();
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error retrieving data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Create the database and table
createDatabase()
  .then(() => createTable())
  .then(() => {
    const PORT = 3000;

    // app.listen(PORT, () => {
    //   console.log(`Server is running on http://localhost:${PORT}`);
    // });
// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    

  })
  .catch((error) => console.error('Error during initialization:', error));
