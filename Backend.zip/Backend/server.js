const express = require("express");
// const { Pool } = require("pg");
const jwt = require("jsonwebtoken");
const config = require("./config");
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use('/image', express.static('image'));
const multer = require('multer');
const cors = require('cors');
const validator = require('validator');
const nodemailer = require('nodemailer');
// const validateAPIKey = require('./api/apikeyMiddleware');
const https = require('https');
const fs = require('fs');

// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

const userAddonRouter = require("./api/userAddon");
const adminAddonRouter = require("./api/adminAddon");
const deliveryRouter = require("./api/delivery");
// const menuRouter = require("./api/WeeklyMenu");
const serviceRouter = require("./api/playstoreUpdate")
// const setupMeals = require("./api/setupMeals")
// twilio
const loginSystem = require("./api/LoginSystem")

const bodyParser = require("body-parser");
const twilio = require("twilio");
app.use(cors());

const {
  createDatabase,
  getDatabasePool,
  createTable,
  // createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  // createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  UpdateRating,
  createAddressTable,
} = require("./db");

const validateAPIKey = require("./api/apikeyMiddleware");

// Routes
app.use("/", userAddonRouter);
app.use("/", adminAddonRouter);
app.use("/",deliveryRouter);
// app.use("/",menuRouter);
app.use("/",serviceRouter);
app.use ("/",loginSystem)
// app.use("/",setupMeals);


// Helper function to generate a UID
const generateUID = (email) => {
  const randomDigits = Math.floor(10000 + Math.random() * 90000); // 5 random digits
  return `${email}${randomDigits}`;
};

// Helper function to generate a JWT token
const generateJWT = (user) => {
  const secretKey = 'your_jwt_secret'; // Replace with your JWT secret key
  return jwt.sign({ id: user.id, email: user.email }, secretKey, { expiresIn: '1h' });
};

app.post('/register', async (req, res) => {
  const { first_name, email, phone_number, created_at, house_name, area, UserInfo, login_status } = req.body;
  const tempPool = getDatabasePool();
  if (!email || !first_name) {
    return res.status(400).json({ status: false, message: 'Email and first_name are required' });
  }

  const uid = generateUID(email);
  const jwt_token = generateJWT({ email });

  try {
    // Check for duplicate email
    const existingUser = await tempPool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ status: false, message: 'Email already registered' });
    }

    // Insert new user with login_status
    await tempPool.query(
      `INSERT INTO users (first_name, email, phone_number, created_at, house_name, area, UserInfo, jwt_token, uid, login_status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [first_name, email, phone_number, created_at, house_name, area, UserInfo, jwt_token, uid, login_status]
    );

    res.status(201).json({ status: true, message: 'User registered successfully', jwt_token });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ status: false, message: 'Internal Server Error' });
  } finally {
    await tempPool.end();
  }
});




app.post('/signin', validateAPIKey,async (req, res) => {
  const { email } = req.body;

  const tempPool = getDatabasePool();
  try {
    // Query to check if user exists
    const query = `
      SELECT *
      FROM users
      WHERE email = $1
    `;
    
    const result = await tempPool.query(query, [email]);

    if (result.rows.length > 0) {
      // User found
      res.json({
        status: true,
        message: 'User found',
        user: result.rows[0] 
      });
    } else {
      // User not found
      res.json({
        status: false,
        message: 'User not found'
      });
    }
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).json({
      status: false,
      message: 'Internal server error'
    });
  }
});


// Get all user dashboard

app.get("/users", async (req, res) => {
  let tempPool;

  try {
    tempPool = getDatabasePool();

    const getUsersQuery = 'SELECT * FROM users';

    const result = await tempPool.query(getUsersQuery);

    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving users:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    if (tempPool) {
      await tempPool.end();
    }
  }
});
app.put('/users/:phoneNumber', async (req, res) => {
  const phoneNumber = req.params.phoneNumber;
  const { firstName, lastName, houseName, roadAndLocation, area, locality, route } = req.body;
  tempPool = getDatabasePool();
  try {
    const updateUserQuery = `
      UPDATE users 
      SET 
        first_name = $1,
        email = $2,
        house_name = $3,
        road_and_location = $4,
        area = $5,
        locality = $6,
        route = $7
      WHERE phone_number = $8
    `;
    
    const values = [firstName, lastName, houseName, roadAndLocation, area, locality, route, phoneNumber];
    
    const result = await tempPool.query(updateUserQuery, values);
    
    res.status(200).json({ message: 'User information updated successfully' });
  } catch (error) {
    console.error('Error updating user information:', error);
    res.status(500).json({ error: 'An error occurred while updating user information' });
  }
});



// Saved images

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './image'); 
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); 
  },
});

const upload = multer({
  storage: multer.memoryStorage(), 
});

// upload image dashboard

app.post("/uploadImage", upload.single('image'), async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    if (!req.file) {
      return res.status(400).json({ status: false, error: "No image file provided" });
    }

    const imageBuffer = req.file.buffer;

    const imageUrl = `https://burgerspotcafeteria.com:5001/image/${req.file.originalname}`;

    try {
      const existingImage = await tempPool.query(
        "SELECT * FROM images WHERE image_url = $1",
        [imageUrl]
      );

      if (existingImage.rows.length > 0) {
        return res.json({ status: false, message: "Image with the same name already exists" });
      }
      const fs = require('fs');
      const imagePath = `./image/${req.file.originalname}`;
      fs.writeFileSync(imagePath, imageBuffer);

      const result = await tempPool.query(
        "INSERT INTO images (image_url) VALUES ($1) RETURNING *",
        [imageUrl]
      );

      const image = result.rows[0];

      res.json({ status: true, message: "Image uploaded successfully", image });
    } catch (error) {
      console.log("Error saving image URL to the database:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// get image dashboard
app.get("/listImages", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getImagesQuery = 'SELECT id, image_url FROM images';

    const result = await tempPool.query(getImagesQuery);
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving images:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// image status update dashboard
app.post('/addons/:id', async (req, res) => {
  const addonId = req.params.id;
  const newStatus = req.body.status;
  const tempPool = getDatabasePool();
  try {
    const updateAddonStatusQuery = `
      UPDATE admin_addon
      SET status = $1
      WHERE id = $2
    `;
    await tempPool.query(updateAddonStatusQuery, [newStatus, addonId]);
    res.status(200).json({ message: ' status updated successfully' });
  } catch (error) {
    console.error('Error updating  status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// delete image dashboard
app.delete("/deleteImage/:id", async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { id } = req.params;

    try {
      const result = await tempPool.query("SELECT * FROM images WHERE id = $1", [id]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "Image not found" });
      }

      await tempPool.query("DELETE FROM images WHERE id = $1", [id]);

      const fs = require('fs');
      const imagePath = `./image/${result.rows[0].image_url.split('/').pop()}`;
      fs.unlinkSync(imagePath);

      res.json({ status: true, message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
})


// Delete user
app.post('/deleteuser', async (req, res) => {
  const { PhoneNumber, FullName, Reason } = req.body;

  // Insert data into deleteuser table
  try {
    const tempPool = getDatabasePool();
    const insertQuery = 'INSERT INTO deleteuser (PhoneNumber, FullName, Reason) VALUES ($1, $2, $3)';
    await tempPool.query(insertQuery, [PhoneNumber, FullName, Reason]);
    res.status(200).json({ message: 'Request submit successfully' });
  } catch (error) {
    if (error.code === '23505') { 
      res.status(400).json({ message: 'Phone number already requested' });
    } else {
      console.log('Error adding data:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
});

app.post('/update-rating', async (req, res) => {
  const { rating } = req.body;

  try {
    const tempPool = getDatabasePool();
    // Insert the rating into the database
    const insertQuery = `
      INSERT INTO rating (rating)
      VALUES ($1)
      RETURNING id
    `;
    const result = await tempPool.query(insertQuery, [rating]);

    const insertedId = result.rows[0].id;
    res.status(200).json({ id: insertedId, message: 'Rating inserted successfully' });
  } catch (error) {
    console.error('Error inserting rating:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Address 
app.post('/address', async (req, res) => {
  const { phone_number, road_and_location, area, locality, landmark } = req.body;

  const insertQuery = `
    INSERT INTO address (phone_number, created_at, road_and_location, area, locality, landmark)
    VALUES ($1, NOW(), $2, $3, $4, $5)
    RETURNING *;
  `;

  const values = [phone_number, road_and_location, area, locality, landmark];
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query(insertQuery, values);
    res.status(201).json({ message: 'Address added successfully', data: result.rows[0] });
  } catch (error) {
    console.error('Error adding address:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/address/:phone_number', async (req, res) => {
  const { phone_number } = req.params;

  const selectQuery = `
    SELECT * FROM address WHERE phone_number = $1;
  `;
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query(selectQuery, [phone_number]);
    if (result.rows.length > 0) {
      res.status(200).json({ data: result.rows });
    } else {
      res.status(404).json({ message: 'Address not found for the given phone number' });
    }
  } catch (error) {
    console.error('Error fetching address:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// DELETE endpoint to delete data from the address table based on ID
app.delete('/deleteAddress/:id', async (req, res) => {
  const { id } = req.params;

  const deleteQuery = `
    DELETE FROM address WHERE id = $1 RETURNING *;
  `;
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query(deleteQuery, [id]);
    if (result.rows.length > 0) {
      res.status(200).json({ message: 'Address deleted successfully', data: result.rows[0] });
    } else {
      res.status(404).json({ message: 'Address not found for the given ID' });
    }
  } catch (error) {
    console.error('Error deleting address:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});




// app.post('/update-user-info', async (req, res) => {
//   const { phone_number, locality } = req.body;

//   if (!phone_number || !locality) {
//     return res.status(400).json({ error: 'phone_number and locality are required fields' });
//   }

//   const checkPhoneNumberQuery = `
//     SELECT COUNT(*) AS count
//     FROM users
//     WHERE phone_number = $1
//   `;

//   const updateLocalityQuery = `
//     UPDATE users
//     SET locality = $1
//     WHERE phone_number = $2
//   `;

//   const tempPool = getDatabasePool();

//   try {
//     const { rows } = await tempPool.query(checkPhoneNumberQuery, [phone_number]);
//     const count = parseInt(rows[0].count);

//     if (count === 0) {
//       return res.status(404).json({ error: 'Phone number not found in the database' });
//     }

//     await tempPool.query(updateLocalityQuery, [locality, phone_number]);
//     return res.status(200).json({ message: 'Locality updated successfully' });
//   } catch (error) {
//     console.error('Error updating Locality:', error);
//     return res.status(500).json({ error: 'Internal server error' });
//   } finally {
//     await tempPool.end();
//   }
// });

app.post('/update-user-info', async (req, res) => {
  const { email, userInfo } = req.body;



  const updateUserInfoQuery = `
    UPDATE users
    SET UserInfo = $1
    WHERE email = $2
    RETURNING *;
  `;
  const tempPool = getDatabasePool();
  try {
    const result = await tempPool.query(updateUserInfoQuery, [userInfo, email]);

    if (result.rowCount === 0) {
      return res.status(404).send({ error: 'User not found' });
    }

    res.send({ message: 'UserInfo updated successfully', user: result.rows[0] });
  } catch (error) {
    console.error('Error updating UserInfo:', error);
    res.status(500).send({ error: 'Internal Server Error' });
  }
});



// Twilio credentials
const accountSid = "ACb3077f569065a1509ae5dc32376378d3";
const authToken = "a5f0c7f72ad25f0377e6a0fb148dff15";
const verifySid = "VA63e65af0af250cf4a40139f3acf4a697";

const twilioClient = new twilio(accountSid, authToken);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Generate OTP
function generateOTP() {
    return Math.floor(1000 + Math.random() * 9000).toString(); 
  }
  
const otpStorage = {};

// Send OTP via WhatsApp
app.post('/send-otp', validateAPIKey ,async (req, res) => {
  const { to } = req.body;

  if (!to) {
    return res.status(400).json({ error: 'Missing phone number' });
  }

  const otp = generateOTP();
  otpStorage[to] = otp;

  try {
    await twilioClient.verify.services(verifySid)
      .verifications
      .create({
        // to: `whatsapp:${to}`,
        // channel: 'whatsapp',
        to: `+${to}`, 
        channel: 'sms', 
        code: otp 
      });

    return res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// Verify OTP
app.post('/verify-otp', validateAPIKey ,async (req, res) => {
  const { to, otp } = req.body;

  if (!to || !otp) {
    return res.status(400).json({ message: 'Missing phone number or OTP' });
  }

  try {
    const verificationCheck = await twilioClient.verify.services(verifySid)
      .verificationChecks
      .create({
        // to: `whatsapp:${to}`,
        to: `+${to}`,
        code: otp
      });

    if (verificationCheck.status === 'approved') {
      return res.status(200).json({ success: true, message: 'OTP verified successfully' });
    } else {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to verify OTP' });
  }
});


// Function to generate a 4-digit OTP
function generateOTP() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

// POST API to send an email
app.post('/send-email',validateAPIKey, async (req, res) => {
  const { to, subject } = req.body;

  if (!to || !subject) {
      return res.status(400).json({ error: 'Missing required fields: to, subject' });
  }

  // Validate email address
  if (!validator.isEmail(to)) {
      return res.status(400).json({ error: 'Invalid email address format' });
  }

  // Generate a 4-digit OTP
  const otp = generateOTP();
  const text = `Your OTP is: ${otp}`;

  // Create a transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
      service: 'gmail', 
      auth: {
         user: 'vijaywilsonofficial@gmail.com',
    pass: 'mpoj kgdb eizz hrvw'
      },
  });

  let mailOptions = {
    from: 'vijaywilsonofficial@gmail.com',
      to: to,
      subject: subject,
      text: text,
  };

  try {
    // Send mail with defined transport object
    let info = await transporter.sendMail(mailOptions);

    // Store the OTP in memory
    otpStorage[to] = otp;
    console.log(`OTP for ${to}: ${otp}`); 

    res.status(200).json({ message: 'Email sent successfully', info: info });
} catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: error.message });
}
});


app.post('/verify-email', validateAPIKey,(req, res) => {
  const { email, otp } = req.body;

  if (!email || !otp) {
      return res.status(400).json({ error: 'Missing required fields: email, otp' });
  }

  // Validate email address
  if (!validator.isEmail(email)) {
      return res.status(400).json({ error: 'Invalid email address format' });
  }

    // Check if the OTP matches
    console.log(`Stored OTP for ${email}: ${otpStorage[email]}`); 
    console.log(`Received OTP: ${otp}`); 
    if (otpStorage[email] && otpStorage[email] === otp) {
        // OTP is valid, remove it from storage
        delete otpStorage[email];
        return res.status(200).json({ message: 'OTP verified successfully',status: true });
    } else {
        return res.status(400).json({ message: 'Invalid OTP',status: false });
    }
});

createDatabase().then(() => createTable())
  // .then(() => createSetupMealsTable())
  .then(() => createImagesTable()) 
  .then(() => createFoodItemsTable()) 
  .then(() => createAddonTable()) 
  .then(() => createDeliveryTable()) 
  // .then(() => createMenuTable()) 
  .then(() => createDeleteUserTable()) 
  .then(() => createUpdatePushTable()) 
  .then(() => UpdateRating()) 
  .then(() => createAddressTable()) 
  .then(() => {

    const PORT = process.env.PORT || 5001;

    // app.listen(PORT, () => {
    //   console.log(`Http Server is running on port ${PORT}`);
    // });

// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    
    
  }).catch((error) => console.error("Error initializing:", error));



  // Total 34 api