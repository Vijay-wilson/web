const express = require("express");
// const { Pool } = require("pg");
const jwt = require("jsonwebtoken");
const config = require("./config");
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use('/image', express.static('image'));
const multer = require('multer');
const cors = require('cors');
// const validateAPIKey = require('./api/apikeyMiddleware');
const https = require('https');
const fs = require('fs');

// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');
const ca = fs.readFileSync('./cert/ca.pem', 'utf8');
const credentials = { key: privateKey, cert: certificate };

// const credentials = { key: privateKey, cert: certificate, ca: ca };
// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

const userAddonRouter = require("./api/userAddon");
const adminAddonRouter = require("./api/adminAddon");
const deliveryRouter = require("./api/delivery");
const menuRouter = require("./api/WeeklyMenu");
const serviceRouter = require("./api/playstoreUpdate")
const setupMeals = require("./api/setupMeals")
// twilio
const bodyParser = require("body-parser");
const twilio = require("twilio");
app.use(cors());

const {
  createDatabase,
  getDatabasePool,
  createTable,
  createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  UpdateRating,
} = require("./db");

const validateAPIKey = require("./api/apikeyMiddleware");

// Routes
app.use("/", userAddonRouter);
app.use("/", adminAddonRouter);
app.use("/",deliveryRouter);
app.use("/",menuRouter);
app.use("/",serviceRouter);
app.use("/",setupMeals);


// Function to generate random alphabetic characters
function generateRandomString(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

const jwtSecretKey = crypto.randomBytes(32).toString('hex');

app.post("/register", validateAPIKey,async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const { FirstName, LastName, PhoneNumber, CreatedAt, HouseName, RoadAndLocation, Area, Locality, Route, UserInfo, FirebaseToken } = req.body;

    try {
      // Get the maximum id from the users table
      const maxIdResult = await tempPool.query("SELECT MAX(id) FROM users");
      const maxId = maxIdResult.rows[0].max || 0; 

      // Generate UID by concatenating PhoneNumber and 4 random alphabetic characters
      const uid = PhoneNumber + generateRandomString(4);

      // Use the next available id
      const result = await tempPool.query(
        "INSERT INTO users (id, first_name, last_name, phone_number, created_at, house_name, road_and_location, area, locality, route, jwt_token, UserInfo, uid, FirebaseToken) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING *",
        [maxId + 1, FirstName, LastName, PhoneNumber, CreatedAt, HouseName, RoadAndLocation, Area, Locality, Route, jwt.sign({ PhoneNumber }, jwtSecretKey), UserInfo, uid, FirebaseToken]
      );

      const user = result.rows[0];
      const token = user.jwt_token;

      const responseObject = {
        status: true,
        message: "User registered successfully",
        id: user.id,
        first_name: user.first_name,
        last_name: user.last_name,
        phone_number: user.phone_number,
        created_at: user.created_at,
        house_name: user.house_name,
        road_and_location: user.road_and_location,
        area: user.area,
        locality: user.locality,
        route: user.route,
        jwt_token: token,
        userinfo: user.UserInfo,
        uid: user.uid,
        firebasetoken: user.FirebaseToken
      };

      res.json(responseObject); 
    } catch (error) {
      // Check if the error is due to a duplicate key violation
      if (error.code === '23505' && error.constraint === 'users_phone_number_key') {
        return res.json({ status: false, message: "Phone number already exists" });
      }

      console.error("Error registering user:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});


app.post("/signin", validateAPIKey,async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { PhoneNumber } = req.body;

    try {
      // Check if the user exists in the database
      const result = await tempPool.query("SELECT * FROM users WHERE phone_number = $1", [PhoneNumber]);

      if (result.rows.length === 0) {
        return res.json([{ status: false, message: "User not available" }]);
      }

      const user = result.rows[0];

      res.json({
        id: user.id,
        status: true,
        message: "Successfully logged in",
        first_name: user.first_name,
        last_name: user.last_name,
        phone_number: user.phone_number,
        created_at: user.created_at,
        house_name: user.house_name,
        road_and_location: user.road_and_location,
        area: user.area,
        locality: user.locality,
        route: user.route,
        jwt_token: user.jwt_token,
        UserInfo: user.UserInfo,
        uid: user.uid,
        FirebaseToken: user.FirebaseToken
      });
    } catch (error) {
      console.error("Error signing in user:", error);
      res.status(500).json([{ status: false, error: "Internal Server Error" }]);
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json([{ status: false, error: "Internal Server Error" }]);
  }
});


app.post("/signout",validateAPIKey, async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const { PhoneNumber } = req.body;

    // Check x-api-key header
    const apiKeyHeader = req.headers['x-api-key'];
    if (apiKeyHeader !== config.apiKey) {
      return res.status(401).json({ status: false, error: "Unauthorized: Invalid API key" });
    }

    // Check Authorization header
    const authorizationHeader = req.headers['authorization'];
    if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
      return res.status(401).json({ status: false, error: "Unauthorized: Missing or invalid Authorization header" });
    }

    const tokenFromHeader = authorizationHeader.split(' ')[1];

    try {
      const result = await tempPool.query("SELECT * FROM users WHERE phone_number = $1", [PhoneNumber]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "User not found" });
      }

      const user = result.rows[0];

      if (tokenFromHeader !== user.jwt_token) {
        return res.status(401).json({ status: false, error: "Unauthorized: Invalid token" });
      }

      const newToken = jwt.sign({ PhoneNumber }, jwtSecretKey);
      await tempPool.query("UPDATE users SET jwt_token = $1 WHERE phone_number = $2", [newToken, PhoneNumber]);
      res.json({
        status: true,
        message: "Logout success",
        new_token: newToken,  
      });
    } catch (error) {
      console.error("Error during signout:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// Get all user dashboard

app.get("/users", async (req, res) => {
  let tempPool;

  try {
    tempPool = getDatabasePool();

    const getUsersQuery = 'SELECT * FROM users';

    const result = await tempPool.query(getUsersQuery);

    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving users:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    if (tempPool) {
      await tempPool.end();
    }
  }
});
app.put('/users/:phoneNumber', async (req, res) => {
  const phoneNumber = req.params.phoneNumber;
  const { firstName, lastName, houseName, roadAndLocation, area, locality, route } = req.body;
  tempPool = getDatabasePool();
  try {
    const updateUserQuery = `
      UPDATE users 
      SET 
        first_name = $1,
        last_name = $2,
        house_name = $3,
        road_and_location = $4,
        area = $5,
        locality = $6,
        route = $7
      WHERE phone_number = $8
    `;
    
    const values = [firstName, lastName, houseName, roadAndLocation, area, locality, route, phoneNumber];
    
    const result = await tempPool.query(updateUserQuery, values);
    
    res.status(200).json({ message: 'User information updated successfully' });
  } catch (error) {
    console.error('Error updating user information:', error);
    res.status(500).json({ error: 'An error occurred while updating user information' });
  }
});



// Saved images

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './image'); 
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); 
  },
});

const upload = multer({
  storage: multer.memoryStorage(), 
});

// upload image dashboard

app.post("/uploadImage", upload.single('image'), async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    if (!req.file) {
      return res.status(400).json({ status: false, error: "No image file provided" });
    }

    const imageBuffer = req.file.buffer;

    const imageUrl = `https://lalaskitchen.in:3000/image/${req.file.originalname}`;

    try {
      const existingImage = await tempPool.query(
        "SELECT * FROM images WHERE image_url = $1",
        [imageUrl]
      );

      if (existingImage.rows.length > 0) {
        return res.json({ status: false, message: "Image with the same name already exists" });
      }
      const fs = require('fs');
      const imagePath = `./image/${req.file.originalname}`;
      fs.writeFileSync(imagePath, imageBuffer);

      const result = await tempPool.query(
        "INSERT INTO images (image_url) VALUES ($1) RETURNING *",
        [imageUrl]
      );

      const image = result.rows[0];

      res.json({ status: true, message: "Image uploaded successfully", image });
    } catch (error) {
      console.log("Error saving image URL to the database:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// get image dashboard
app.get("/listImages", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getImagesQuery = 'SELECT id, image_url FROM images';

    const result = await tempPool.query(getImagesQuery);
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving images:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// image status update dashboard
app.post('/addons/:id', async (req, res) => {
  const addonId = req.params.id;
  const newStatus = req.body.status;
  const tempPool = getDatabasePool();
  try {
    const updateAddonStatusQuery = `
      UPDATE admin_addon
      SET status = $1
      WHERE id = $2
    `;
    await tempPool.query(updateAddonStatusQuery, [newStatus, addonId]);
    res.status(200).json({ message: ' status updated successfully' });
  } catch (error) {
    console.error('Error updating  status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// delete image dashboard
app.delete("/deleteImage/:id", async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { id } = req.params;

    try {
      const result = await tempPool.query("SELECT * FROM images WHERE id = $1", [id]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "Image not found" });
      }

      await tempPool.query("DELETE FROM images WHERE id = $1", [id]);

      const fs = require('fs');
      const imagePath = `./image/${result.rows[0].image_url.split('/').pop()}`;
      fs.unlinkSync(imagePath);

      res.json({ status: true, message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
})


// Delete user
app.post('/deleteuser', async (req, res) => {
  const { PhoneNumber, FullName, Reason } = req.body;

  // Insert data into deleteuser table
  try {
    const tempPool = getDatabasePool();
    const insertQuery = 'INSERT INTO deleteuser (PhoneNumber, FullName, Reason) VALUES ($1, $2, $3)';
    await tempPool.query(insertQuery, [PhoneNumber, FullName, Reason]);
    res.status(200).json({ message: 'Request submit successfully' });
  } catch (error) {
    if (error.code === '23505') { 
      res.status(400).json({ message: 'Phone number already requested' });
    } else {
      console.log('Error adding data:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
});

app.post('/update-rating', async (req, res) => {
  const { rating } = req.body;

  try {
    const tempPool = getDatabasePool();
    // Insert the rating into the database
    const insertQuery = `
      INSERT INTO rating (rating)
      VALUES ($1)
      RETURNING id
    `;
    const result = await tempPool.query(insertQuery, [rating]);

    const insertedId = result.rows[0].id;
    res.status(200).json({ id: insertedId, message: 'Rating inserted successfully' });
  } catch (error) {
    console.error('Error inserting rating:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Twilio credentials
const accountSid = "ACb3077f569065a1509ae5dc32376378d3";
const authToken = "a5f0c7f72ad25f0377e6a0fb148dff15";
const verifySid = "VA63e65af0af250cf4a40139f3acf4a697";

const twilioClient = new twilio(accountSid, authToken);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Generate OTP
function generateOTP() {
    return Math.floor(1000 + Math.random() * 9000).toString(); 
  }
  
const otpStorage = {};

// Send OTP via WhatsApp
app.post('/send-otp', validateAPIKey ,async (req, res) => {
  const { to } = req.body;

  if (!to) {
    return res.status(400).json({ error: 'Missing phone number' });
  }

  const otp = generateOTP();
  otpStorage[to] = otp;

  try {
    await twilioClient.verify.services(verifySid)
      .verifications
      .create({
        // to: `whatsapp:${to}`,
        // channel: 'whatsapp',
        to: `+${to}`, 
        channel: 'sms', 
        code: otp 
      });

    return res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// Verify OTP
app.post('/verify-otp', validateAPIKey ,async (req, res) => {
  const { to, otp } = req.body;

  if (!to || !otp) {
    return res.status(400).json({ message: 'Missing phone number or OTP' });
  }

  try {
    const verificationCheck = await twilioClient.verify.services(verifySid)
      .verificationChecks
      .create({
        // to: `whatsapp:${to}`,
        to: `+${to}`,
        code: otp
      });

    if (verificationCheck.status === 'approved') {
      return res.status(200).json({ success: true, message: 'OTP verified successfully' });
    } else {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to verify OTP' });
  }
});


createDatabase().then(() => createTable())
  .then(() => createSetupMealsTable())
  .then(() => createImagesTable()) 
  .then(() => createFoodItemsTable()) 
  .then(() => createAddonTable()) 
  .then(() => createDeliveryTable()) 
  .then(() => createMenuTable()) 
  .then(() => createDeleteUserTable()) 
  .then(() => createUpdatePushTable()) 
  .then(() => UpdateRating()) 
  .then(() => {

    const PORT = process.env.PORT || 3000;

    // app.listen(PORT, () => {
    //   console.log(`Http Server is running on port ${PORT}`);
    // });

// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    
    
  }).catch((error) => console.error("Error initializing:", error));



  // Total 34 api