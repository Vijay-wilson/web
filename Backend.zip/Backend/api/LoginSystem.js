const express = require("express");
const { getDatabasePool } = require("../db");
const router = express.Router();

const validateAPIKey = require("./apikeyMiddleware");

router.post('/login-status', validateAPIKey, async (req, res) => {
    const { email, login_status } = req.body;
  
    if (typeof login_status !== 'boolean') {
      return res.status(400).json({ error: 'login_status must be a boolean' });
    }
  
    const updateLoginStatusQuery = `
      UPDATE users
      SET login_status = $1
      WHERE email = $2
      RETURNING *;
    `;
  
    const tempPool = getDatabasePool();
  
    try {
      const result = await tempPool.query(updateLoginStatusQuery, [login_status, email]);
  
      if (result.rowCount === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      res.status(200).json({ message: 'Login status updated successfully', user: result.rows[0] });
    } catch (error) {
      console.error('Error updating login status:', error);
      res.status(500).json({ error: 'Internal server error' });
    } finally {
      await tempPool.end();
    }
  });


module.exports = router;