const express = require("express");
const { getDatabasePool } = require("../db");
const router = express.Router();

router.post("/menu", async (req, res) => {
    try {
      const tempPool = getDatabasePool();
  
      const { VegType, menuType, weekType, menu } = req.body;
  
      try {
        const menuJson = JSON.stringify(menu);
        const result = await tempPool.query(
            "INSERT INTO menu (VegType, menuType, weekType, menu, status) VALUES ($1, $2, $3, $4, $5) RETURNING *",
            [VegType, menuType, weekType, menuJson, true] 
        );
        
        
        const newMenu = result.rows[0];
  
        res.json({ status: true, message: "Menu created successfully", menu: newMenu });
      } catch (error) {
        console.error("Error creating menu:", error);
        res.status(500).json({ status: false, error: "Internal Server Error" });
      }
    } catch (error) {
      console.error("Error creating pool:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  });
  

router.get("/menu", async (req, res) => {
    try {
      const tempPool = getDatabasePool();
  
      const getMenuQuery = 'SELECT * FROM menu';
  
      const result = await tempPool.query(getMenuQuery);
  
      res.json(result.rows);
    } catch (error) {
      console.error('Error retrieving menus:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });


router.put('/menu', async (req, res) => {
    const { id, status } = req.body;
    const tempPool = getDatabasePool();
    try {
      const updateStatusQuery = `
        UPDATE menu
        SET status = $1
        WHERE id = $2
      `;
      await tempPool.query(updateStatusQuery, [status, id]);
      res.status(200).json({
        success: true,
        message: 'Status updated successfully',
        updatedStatus: status
      });
    } catch (error) {
      console.error('Error updating status:', error);
      res.status(500).json({
        success: false,
        error: 'Internal Server Error'
      });
    }
  });
  
  
module.exports = router;