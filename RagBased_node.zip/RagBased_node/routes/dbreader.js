const express = require("express");
const router = express.Router();
const { Pool } = require('pg');
const { createEmbedings } = require("./embedings");
const { Groq } = require("groq-sdk");
const fs = require("fs");
var PDFParser = require("pdf2json");
const parser = new PDFParser(this, 1);

// Database configuration
const dbConfig = {
  user: "postgres",
  host: "localhost",
  database: "chat",
  password: "143143",
  port: 5432,
};

// Create database if it doesn't exist
async function initializeDatabase() {
  // Connect to postgres default database to create new database
  const tempPool = new Pool({
    ...dbConfig,
    database: 'postgres'
  });

  try {
    // Check if database exists
    const dbCheck = await tempPool.query(
      "SELECT datname FROM pg_database WHERE datname = $1",
      [dbConfig.database]
    );

    if (dbCheck.rows.length === 0) {
      console.log(`Creating database ${dbConfig.database}...`);
      await tempPool.query(`CREATE DATABASE ${dbConfig.database}`);
      console.log('Database created successfully');
    } else {
      console.log('Database already exists');
    }

    // Create tables in the actual database
    const pool = new Pool(dbConfig);
    
    await pool.query(`
      CREATE EXTENSION IF NOT EXISTS vector;

      CREATE TABLE IF NOT EXISTS sessions (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS documents (
        id SERIAL PRIMARY KEY,
        text TEXT NOT NULL,
        embedding vector(1024)
      );

      CREATE TABLE IF NOT EXISTS conversations (
        id SERIAL PRIMARY KEY,
        session_id INTEGER REFERENCES sessions(id),
        message TEXT NOT NULL,
        role VARCHAR(10) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_documents_embedding ON documents 
      USING ivfflat (embedding vector_cosine_ops)
      WITH (lists = 100);
    `);

    console.log('Tables created successfully');
    await pool.end();
    await tempPool.end();
  } catch (error) {
    console.error('Database initialization error:', error);
    await tempPool.end();
    throw error;
  }
}

// Initialize database on startup
initializeDatabase().catch(console.error);

// Create connection pool
const pool = new Pool(dbConfig);

// Test connection
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('Database connected successfully at:', res.rows[0].now);
  }
});

// Helper function to format embedding array for PostgreSQL vector type
function formatEmbeddingForPostgres(embedding) {
  return `[${embedding.join(',')}]`;
}

router.get("/", async function (req, res, next) {
  try {
    const result = await pool.query('SELECT NOW()');
    res.json({ status: "Connected", timestamp: result.rows[0].now });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Database connection failed" });
  }
});

router.post("/load-document", async (req, res) => {
  try {
    parser.loadPDF("./docs/Payyavoor.pdf");
    parser.on("pdfParser_dataReady", async (data) => {
      await fs.writeFileSync("./context.txt", parser.getRawTextContent());
      const content = await fs.readFileSync("./context.txt", "utf-8");
      const splitContent = content.split("\n");

      for (const line of splitContent) {
        if (line.trim()) {
          const embeddings = await createEmbedings(line);
          const formattedEmbedding = formatEmbeddingForPostgres(embeddings.data[0].embedding);
          await pool.query(
            'INSERT INTO documents (text, embedding) VALUES ($1, $2::vector)',
            [line, formattedEmbedding]
          );
          console.log('Inserted:', line.substring(0, 50) + '...');
        }
      }
      res.json("Document processing completed");
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error processing document" });
  }
});

router.get("/embeddings", async (req, res) => {
  try {
    const embeddings = await createEmbedings("Hello World");
    // Format the embeddings before sending to demonstrate the correct format
    const formattedEmbedding = formatEmbeddingForPostgres(embeddings.data[0].embedding);
    res.json({
      raw: embeddings,
      formatted: formattedEmbedding
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error generating embeddings" });
  }
});

router.post("/conversation", async (req, res) => {
  try {
    let sessionId = req.body.sessionId;
    
    // Create or retrieve session
    if (!sessionId) {
      const sessionResult = await pool.query(
        'INSERT INTO sessions DEFAULT VALUES RETURNING id'
      );
      sessionId = sessionResult.rows[0].id;
    } else {
      const sessionCheck = await pool.query(
        'SELECT id FROM sessions WHERE id = $1',
        [sessionId]
      );
      if (sessionCheck.rows.length === 0) {
        return res.status(404).json({ message: "Session not found" });
      }
    }

    const message = req.body.message;
    
    // Store user message
    await pool.query(
      'INSERT INTO conversations (session_id, message, role) VALUES ($1, $2, $3)',
      [sessionId, message, 'USER']
    );

    // Generate embeddings for the query
    const messageVector = await createEmbedings(message);
    const formattedVector = formatEmbeddingForPostgres(messageVector.data[0].embedding);

    // Perform vector similarity search
    const similarDocs = await pool.query(`
      SELECT text, 1 - (embedding <=> $1::vector) as similarity
      FROM documents
      ORDER BY embedding <=> $1::vector
      LIMIT 10
    `, [formattedVector]);

    // Generate response using Groq
    const groq = new Groq({
      apiKey: process.env.GROQ_API_KEY,
    });

    const chat = await groq.chat.completions.create({
      model: "llama3-8b-8192",
      messages: [
        {
          role: "system",
          content: "You are a humble helper who can answer questions asked by users from the given context.",
        },
        {
          role: "user",
          content: `${similarDocs.rows.map(doc => doc.text).join('\n')}
          \n
          From the above context, answer the following question: ${message}`,
        },
      ],
    });

    // Store AI response
    await pool.query(
      'INSERT INTO conversations (session_id, message, role) VALUES ($1, $2, $3)',
      [sessionId, chat.choices[0].message.content, 'ASSISTANT']
    );

    res.json({
      sessionId,
      response: chat.choices[0].message.content
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Something went wrong" });
  }
});

module.exports = router;