
const express = require("express");
const router = express.Router();
const { Pool } = require('pg');
const { createEmbedings } = require("./embedings");
const { Groq } = require("groq-sdk");
const fs = require("fs");
var PDFParser = require("pdf2json");
const parser = new PDFParser(this, 1);

// Database configuration
const dbConfig = {
  user: "postgres",
  host: "localhost",
  database: "mydb",
  password: "143143",
  port: 5432,
};

// Create database if it doesn't exist
async function initializeDatabase() {
  // Connect to postgres default database to create new database
  const tempPool = new Pool({
    ...dbConfig,
    database: 'postgres'
  });

  try {
    // Check if database exists
    const dbCheck = await tempPool.query(
      "SELECT datname FROM pg_database WHERE datname = $1",
      [dbConfig.database]
    );

    if (dbCheck.rows.length === 0) {
      console.log(`Creating database ${dbConfig.database}...`);
      await tempPool.query(`CREATE DATABASE ${dbConfig.database}`);
      console.log('Database created successfully');
    } else {
      console.log('Database already exists');
    }

    // Create tables in the actual database
    const pool = new Pool(dbConfig);
    
    await pool.query(`
      CREATE EXTENSION IF NOT EXISTS vector;

      CREATE TABLE IF NOT EXISTS sessions (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS documents (
        id SERIAL PRIMARY KEY,
        text TEXT NOT NULL,
        embedding vector(1024)
      );

      CREATE TABLE IF NOT EXISTS conversations (
        id SERIAL PRIMARY KEY,
        session_id INTEGER REFERENCES sessions(id),
        message TEXT NOT NULL,
        role VARCHAR(10) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS menu_items (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price_in_inr DECIMAL(10,2) NOT NULL,
        category VARCHAR(50) NOT NULL,
        available BOOLEAN DEFAULT true,
        prep_time VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_documents_embedding ON documents 
      USING ivfflat (embedding vector_cosine_ops)
      WITH (lists = 100);
    `);

    // Insert sample menu items if they don't exist
    const menuItems = [
      {
        name: 'Grilled Chicken Caesar Salad',
        description: 'Fresh romaine lettuce, grilled chicken breast, parmesan cheese, croutons.',
        price_in_inr: 1078.17,
        category: 'Salads',
        prep_time: '15 minutes'
      },
      {
        name: 'Margherita Pizza',
        description: 'Fresh mozzarella, basil, tomato sauce on thin crust.',
        price_in_inr: 1244.17,
        category: 'Pizza',
        prep_time: '20 minutes'
      },
      {
        name: 'Spicy Beef Burger',
        description: 'Angus beef patty, jalapeños, pepper jack cheese, chipotle mayo.',
        price_in_inr: 1161.17,
        category: 'Burgers',
        prep_time: '18 minutes'
      },
      {
        name: 'Vegetable Stir Fry',
        description: 'Mixed vegetables, tofu, rice noodles in soy-ginger sauce.',
        price_in_inr: 995.17,
        category: 'Asian',
        prep_time: '15 minutes'
      }
    ];

    // Check if menu items exist
    const menuCheck = await pool.query('SELECT COUNT(*) FROM menu_items');
    
    if (parseInt(menuCheck.rows[0].count) === 0) {
      console.log('Inserting sample menu items...');
      for (const item of menuItems) {
        await pool.query(
          `INSERT INTO menu_items (name, description, price_in_inr, category, prep_time) 
           VALUES ($1, $2, $3, $4, $5)`,
          [item.name, item.description, item.price_in_inr, item.category, item.prep_time]
        );
      }
      console.log('Sample menu items inserted successfully');
    }

    console.log('Tables created successfully');
    await pool.end();
    await tempPool.end();
  } catch (error) {
    console.error('Database initialization error:', error);
    await tempPool.end();
    throw error;
  }
}

// Initialize database on startup
initializeDatabase().catch(console.error);

// Create connection pool
const pool = new Pool(dbConfig);

// Test connection
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('Database connected successfully at:', res.rows[0].now);
  }
});

// Helper function to format embedding array for PostgreSQL vector type
function formatEmbeddingForPostgres(embedding) {
  return `[${embedding.join(',')}]`;
}

router.get("/", async function (req, res, next) {
  try {
    const result = await pool.query('SELECT NOW()');
    res.json({ status: "Connected", timestamp: result.rows[0].now });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Database connection failed" });
  }
});

router.post("/load-document", async (req, res) => {
  try {
    parser.loadPDF("./docs/food.pdf");
    parser.on("pdfParser_dataReady", async (data) => {
      await fs.writeFileSync("./context.txt", parser.getRawTextContent());
      const content = await fs.readFileSync("./context.txt", "utf-8");
      const splitContent = content.split("\n");

      for (const line of splitContent) {
        if (line.trim()) {
          const embeddings = await createEmbedings(line);
          const formattedEmbedding = formatEmbeddingForPostgres(embeddings.data[0].embedding);
          await pool.query(
            'INSERT INTO documents (text, embedding) VALUES ($1, $2::vector)',
            [line, formattedEmbedding]
          );
          console.log('Inserted:', line.substring(0, 50) + '...');
        }
      }
      res.json("Document processing completed");
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error processing document" });
  }
});

router.get("/embeddings", async (req, res) => {
  try {
    const embeddings = await createEmbedings("Hello World");
    // Format the embeddings before sending to demonstrate the correct format
    const formattedEmbedding = formatEmbeddingForPostgres(embeddings.data[0].embedding);
    res.json({
      raw: embeddings,
      formatted: formattedEmbedding
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error generating embeddings" });
  }
});


router.post("/chat", async (req, res) => {
  try {
    let sessionId = req.body.sessionId;
    
    // Create or retrieve session
    if (!sessionId) {
      const sessionResult = await pool.query(
        'INSERT INTO sessions DEFAULT VALUES RETURNING id'
      );
      sessionId = sessionResult.rows[0].id;
    }

    const message = req.body.message;
    
    // Store user message
    await pool.query(
      'INSERT INTO conversations (session_id, message, role) VALUES ($1, $2, $3)',
      [sessionId, message, 'USER']
    );

    // Get all available menu items
    const menuItems = await pool.query(`
      SELECT 
        name,
        description,
        price_in_inr,
        category,
        prep_time
      FROM menu_items 
      WHERE available = true
    `);

    // Generate response using Groq
    const groq = new Groq({
      apiKey: process.env.GROQ_API_KEY,
    });

    const chat = await groq.chat.completions.create({
      model: "llama3-8b-8192",
      messages: [
        {
          role: "system",
          content: `You are a friendly food recommendation bot. Analyze the user's request and recommend dishes from the menu.
          Always structure your response exactly like this example:
          {
            "recommendations": [
              {
                "name": "Dish Name",
                "reason": "Reason for recommendation",
                "price_in_inr": 1000.00,
                "prep_time": "15 minutes"
              }
            ],
            "message": "Friendly explanation message"
          }
          Important: Return ONLY valid JSON matching this exact structure.`,
        },
        {
          role: "user",
          content: `Available menu items: ${JSON.stringify(menuItems.rows)}
          User request: ${message}`,
        },
      ],
      temperature: 0.7, // Add temperature to control randomness
      max_tokens: 1000, // Limit response length
    });

    let response;
    try {
      response = JSON.parse(chat.choices[0].message.content);
      
      // Validate response structure
      if (!response.recommendations || !Array.isArray(response.recommendations) || !response.message) {
        throw new Error('Invalid response structure');
      }
    } catch (parseError) {
      console.error('AI response parsing error:', parseError);
      
      // Fallback response if JSON parsing fails
      response = {
        recommendations: [
          {
            name: menuItems.rows[0].name,
            reason: "I apologize, but I'm having trouble processing your request. Here's our most popular dish.",
            price_in_inr: menuItems.rows[0].price_in_inr,
            prep_time: menuItems.rows[0].prep_time
          }
        ],
        message: "I apologize, but I'm having trouble understanding your request. I've suggested our most popular dish. Could you please try rephrasing your question?"
      };
    }

    // Store AI response
    await pool.query(
      'INSERT INTO conversations (session_id, message, role) VALUES ($1, $2, $3)',
      [sessionId, JSON.stringify(response), 'ASSISTANT']
    );

    res.json({
      sessionId,
      ...response
    });
  } catch (error) {
    console.error('Chat endpoint error:', error);
    res.status(500).json({ 
      message: "Something went wrong with your request. Please try again.",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

module.exports = router;