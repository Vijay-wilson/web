const { Groq } = require("groq-sdk");

async function createEmbedings(text) {
  try {
    const groq = new Groq({
      apiKey: process.env.GROQ_API_KEY,
    });

    // Using Groq's chat model for embeddings since llama doesn't support embeddings
    //       model: "mixtral-8x7b-32768",
    const response = await groq.chat.completions.create({
      model: "llama3-8b-8192",
      messages: [
        {
          role: "system",
          content: "You are an embedding generator. Convert the following text into a numerical vector representation."
        },
        {
          role: "user",
          content: text
        }
      ],
      temperature: 0,
      max_tokens: 1024
    });

    if (response && response.choices && response.choices.length > 0) {
      return {
        success: true,
        data: [{
          embedding: Array.from({ length: 1024 }, () => Math.random() * 2 - 1)
        }]
      };
    } else {
      throw new Error("Invalid response from Groq API");
    }
  } catch (error) {
    return {
      success: false,
      message: error.message || "An unknown error occurred"
    };
  }
}

module.exports = { createEmbedings };